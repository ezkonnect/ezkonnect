package common;

public class Constants {
	
	public static final String GET_USER_SUBSCRIPTIONS = "getUserSubscriptions";

}
