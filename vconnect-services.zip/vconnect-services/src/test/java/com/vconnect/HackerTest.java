package com.vconnect;

public class HackerTest {
	
	public static void main(String[] args) 

    {
        System.out.println ("1");

    }

}
